<?php
// Database connection
$host = 'localhost:8111';
$username = 'root';
$password = '';
$database = 'ecommerce';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle filter criteria
$selectedCategories = isset($_POST['categories']) ? explode(',', $_POST['categories']) : [];
$selectedSizes = isset($_POST['sizes']) ? explode(',', $_POST['sizes']) : [];
$selectedPrices = isset($_POST['prices']) ? explode(',', $_POST['prices']) : [];

// Build SQL query based on selected filters
$sql = "SELECT * FROM products WHERE 1";

if (!empty($selectedCategories)) {
    $categoryFilter = implode(',', $selectedCategories);
    $sql .= " AND category_id IN ($categoryFilter)";
}

if (!empty($selectedSizes)) {
    $sizeFilter = "'" . implode("','", $selectedSizes) . "'";
    $sql .= " AND size IN ($sizeFilter)";
}

if (!empty($selectedPrices)) {
    $priceFilter = '';
    foreach ($selectedPrices as $priceRange) {
        // Continue the PHP code
        list($min, $max) = explode('-', $priceRange);
        $priceFilter .= "(price BETWEEN $min AND $max) OR ";
    }
    $priceFilter = rtrim($priceFilter, 'OR ');
    $sql .= " AND ($priceFilter)";
}

// Execute SQL query
$result = $conn->query($sql);

// Check for SQL query errors
if (!$result) {
    die('Error in SQL query: ' . $conn->error);
}

// Display filtered products
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='product-card'>";
        echo "<h4>{$row['name']}</h4>";
        echo "<p>Category: {$row['category_id']}</p>";

        // Check if 'size' index exists before using it
        if (isset($row['size'])) {
            echo "<p>Size: {$row['size']}</p>";
        }

        echo "<p>Price: {$row['price']}</p>";
        echo "</div>";
    }
} else {
    echo "<p>No products found.</p>";
}

$conn->close();
?>

