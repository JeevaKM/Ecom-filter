document.addEventListener("DOMContentLoaded", function () {
    
    filterProducts();

    
    const categoryFilters = document.querySelectorAll('.category-filter');
    const sizeFilters = document.querySelectorAll('.size-filter');
    const priceFilters = document.querySelectorAll('.price-filter');

    categoryFilters.forEach(filter => {
        filter.addEventListener('change', function () {
            
            categoryFilters.forEach(otherFilter => {
                if (otherFilter !== filter) {
                    otherFilter.checked = false;
                }
            });
            filterProducts();
        });
    });

    sizeFilters.forEach(filter => {
        filter.addEventListener('change', function () {
           
            sizeFilters.forEach(otherFilter => {
                if (otherFilter !== filter) {
                    otherFilter.checked = false;
                }
            });
            filterProducts();
        });
    });

    priceFilters.forEach(filter => {
        filter.addEventListener('change', function () {
      
            priceFilters.forEach(otherFilter => {
                if (otherFilter !== filter) {
                    otherFilter.checked = false;
                }
            });
            filterProducts();
        });
    });
});


function filterProducts() {
   
    const selectedCategories = Array.from(document.querySelectorAll('.category-filter:checked'))
        .map(checkbox => parseInt(checkbox.value));

  
    const selectedSizes = Array.from(document.querySelectorAll('.size-filter:checked'))
        .map(checkbox => checkbox.value);

  
    const selectedPrices = Array.from(document.querySelectorAll('.price-filter:checked'))
        .map(checkbox => checkbox.value);

 
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'filter.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
           
            document.getElementById('productGrid').innerHTML = xhr.responseText;
        }
    };

   
    const categoryParams = selectedCategories.length > 0 ? 'categories=' + selectedCategories.join(',') : '';
    const sizeParams = selectedSizes.length > 0 ? 'sizes=' + selectedSizes.join(',') : '';
    const priceParams = selectedPrices.length > 0 ? 'prices=' + selectedPrices.join(',') : '';

   
    const filterParams = [categoryParams, sizeParams, priceParams].filter(Boolean).join('&');

    
    xhr.send(filterParams);
}
document.addEventListener("DOMContentLoaded", function () {
   
    filterProducts();

    
    const categoryFilters = document.querySelectorAll('.category-filter');
    const sizeFilters = document.querySelectorAll('.size-filter');
    const priceFilters = document.querySelectorAll('.price-filter');

    categoryFilters.forEach(filter => {
        filter.addEventListener('change', filterProducts);
    });

    sizeFilters.forEach(filter => {
        filter.addEventListener('change', filterProducts);
    });

    priceFilters.forEach(filter => {
        filter.addEventListener('change', filterProducts);
    });
});

function filterProducts() {
    
    const selectedCategories = Array.from(document.querySelectorAll('.category-filter:checked'))
        .map(checkbox => parseInt(checkbox.value));

    
    const selectedSizes = Array.from(document.querySelectorAll('.size-filter:checked'))
        .map(checkbox => checkbox.value);

   
    const selectedPrices = Array.from(document.querySelectorAll('.price-filter:checked'))
        .map(checkbox => checkbox.value);

   
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'filter.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            
            document.getElementById('productGrid').innerHTML = xhr.responseText;
        }
    };

    // Convert selected categories, sizes, and prices to strings
    const categoryParams = selectedCategories.length > 0 ? 'categories=' + selectedCategories.join(',') : '';
    const sizeParams = selectedSizes.length > 0 ? 'sizes=' + selectedSizes.join(',') : '';
    const priceParams = selectedPrices.length > 0 ? 'prices=' + selectedPrices.join(',') : '';

   
    const filterParams = [categoryParams, sizeParams, priceParams].filter(Boolean).join('&');

    
    xhr.send(filterParams);
}
